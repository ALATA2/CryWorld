import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';
import { Water } from 'three/addons/objects/Water.js';
import { Sky } from 'three/addons/objects/Sky.js';
import { VoxelTerrain } from './marching_cubes.js';

// ==========================================
// GAME STATE variables
// ==========================================
let scene, camera, renderer, clock;
let terrain, water, sky, sun;
let controls;

// Movement flags & velocities
const velocity = new THREE.Vector3();
const direction = new THREE.Vector3();
const keyStates = {
    KeyW: false,
    KeyA: false,
    KeyS: false,
    KeyD: false,
    Space: false
};

let isGrounded = false;
const playerHeight = 1.8; // Camera height above ground
const gravity = 25.0; // Gravity acceleration (m/s^2)
const jumpForce = 10.0; // Jump power
const moveSpeed = 40.0; // Walk speed
const runSpeed = 70.0; // Shift-run speed (optional)

// Digging / Building continuous interaction state
let isDigging = false;
let isBuilding = false;
let lastInteractionTime = 0;
const interactionCooldown = 80; // ms between digs when holding mouse button

// Raycaster for terrain interaction
const raycaster = new THREE.Raycaster();
const screenCenter = new THREE.Vector2(0, 0);

// DOM Elements
const blocker = document.getElementById('blocker');
const instructions = document.getElementById('instructions');
const posInfo = document.getElementById('pos-info');
const fpsCounter = document.getElementById('fps-counter');
const crosshair = document.getElementById('crosshair');

// FPS counting variables
let fpsLastTime = performance.now();
let fpsFrames = 0;

// Initialize the game
init();
animate();

// ==========================================
// CORE INITIALIZATION
// ==========================================
function init() {
    // 1. Scene & Camera Setup
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0xbfe3dd);
    scene.fog = new THREE.FogExp2(0xbfe3dd, 0.005);

    camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 2000);
    camera.position.set(0, 20, 45); // Start on beach slope

    clock = new THREE.Clock();

    // 2. Renderer Setup
    renderer = new THREE.WebGLRenderer({ antialias: true, canvas: document.getElementById('game-canvas') });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Limit pixel ratio to 2 for performance
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;

    // 3. Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffe8d6, 1.2);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 150;
    const d = 60;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0005;
    scene.add(dirLight);

    // 4. Sky and Sun Configuration
    sky = new Sky();
    sky.scale.setScalar(450000);
    scene.add(sky);

    sun = new THREE.Vector3();
    const effectController = {
        turbidity: 10,
        rayleigh: 2,
        mieCoefficient: 0.005,
        mieDirectionalG: 0.8,
        elevation: 18, // Late afternoon sun
        azimuth: 180,  // Facing North-South
        exposure: renderer.toneMappingExposure
    };

    function updateSky() {
        const uniforms = sky.material.uniforms;
        uniforms['turbidity'].value = effectController.turbidity;
        uniforms['rayleigh'].value = effectController.rayleigh;
        uniforms['mieCoefficient'].value = effectController.mieCoefficient;
        uniforms['mieDirectionalG'].value = effectController.mieDirectionalG;

        const phi = THREE.MathUtils.degToRad(90 - effectController.elevation);
        const theta = THREE.MathUtils.degToRad(effectController.azimuth);

        sun.setFromSphericalCoords(1, phi, theta);
        uniforms['sunPosition'].value.copy(sun);
        
        dirLight.position.copy(sun).multiplyScalar(100);
        
        // Update fog color to match sun elevation
        scene.fog.color.setHSL(0.55, 0.4, 0.75);
    }
    updateSky();

    // 5. Water Setup
    const waterGeometry = new THREE.PlaneGeometry(10000, 10000);
    water = new Water(
        waterGeometry,
        {
            textureWidth: 512,
            textureHeight: 512,
            waterNormals: new THREE.TextureLoader().load('https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/waternoise.png', function (texture) {
                texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
            }),
            sunDirection: sun,
            sunColor: 0xffe8d6,
            waterColor: 0x00aaff, // Turquoise Caribbean water
            distortionScale: 3.7,
            fog: scene.fog !== undefined
        }
    );
    water.rotation.x = -Math.PI / 2;
    water.position.y = 8.0; // Sea level at Y = 8.0 meters
    scene.add(water);

    // 6. Marching Cubes Voxel Terrain Setup
    // Width = 64, Height = 32, Depth = 64, VoxelScale = 2.0 (total island footprint: 128m x 64m x 128m)
    terrain = new VoxelTerrain(scene, 64, 32, 64, 2.0);

    // Position player safely on the beach
    const startX = 0;
    const startZ = 45;
    const testPos = new THREE.Vector3(startX, 20, startZ);
    const groundY = terrain.getSurfaceHeight(testPos, 32);
    camera.position.set(startX, groundY + playerHeight, startZ);

    // 7. Player Controls (First Person) Setup
    controls = new PointerLockControls(camera, document.body);

    blocker.addEventListener('click', () => {
        controls.lock();
    });

    controls.addEventListener('lock', () => {
        blocker.style.display = 'none';
    });

    controls.addEventListener('unlock', () => {
        blocker.style.display = 'flex';
        // Reset movement states when pausing
        keyStates.KeyW = false;
        keyStates.KeyA = false;
        keyStates.KeyS = false;
        keyStates.KeyD = false;
        keyStates.Space = false;
        isDigging = false;
        isBuilding = false;
    });

    scene.add(controls.getObject());

    // 8. Event Listeners
    setupInputListeners();

    // Adjust sizes on resize
    window.addEventListener('resize', onWindowResize);
}

// ==========================================
// INPUT HANDLING
// ==========================================
function setupInputListeners() {
    // Keyboard inputs
    const onKeyDown = function (event) {
        if (event.code in keyStates) {
            keyStates[event.code] = true;
        }
        if (event.code === 'Space' && isGrounded) {
            velocity.y = jumpForce;
            isGrounded = false;
        }
    };

    const onKeyUp = function (event) {
        if (event.code in keyStates) {
            keyStates[event.code] = false;
        }
    };

    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);

    // Mouse clicks for Digging and Building
    const onMouseDown = function (event) {
        if (!controls.isLocked) return;

        if (event.button === 0) { // Left Click
            isDigging = true;
            isBuilding = false;
            crosshair.classList.add('active');
        } else if (event.button === 2) { // Right Click
            isBuilding = true;
            isDigging = false;
            crosshair.classList.add('active');
        }
    };

    const onMouseUp = function (event) {
        if (event.button === 0) {
            isDigging = false;
        } else if (event.button === 2) {
            isBuilding = false;
        }
        if (!isDigging && !isBuilding) {
            crosshair.classList.remove('active');
        }
    };

    document.addEventListener('mousedown', onMouseDown);
    document.addEventListener('mouseup', onMouseUp);
    
    // Prevent right click menu in game
    document.addEventListener('contextmenu', (event) => {
        if (controls.isLocked) {
            event.preventDefault();
        }
    });
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// Perform raycasting and modify terrain
function handleTerrainInteraction() {
    if (!controls.isLocked) return;
    if (!isDigging && !isBuilding) return;

    const now = performance.now();
    if (now - lastInteractionTime < interactionCooldown) return;
    lastInteractionTime = now;

    // Cast ray from center of camera view
    raycaster.setFromCamera(screenCenter, camera);
    
    // Intersect chunk meshes in the terrain group
    const intersects = raycaster.intersectObjects(terrain.group.children);

    if (intersects.length > 0) {
        const hit = intersects[0];
        // Ensure we hit a valid surface that is reasonably close (e.g. within 35 meters)
        if (hit.distance < 35.0) {
            const mode = isDigging ? 'dig' : 'build';
            
            // Dig/Build radius: 3.5 meters
            const modified = terrain.modifyTerrain(hit.point, 3.5, mode);
            
            if (modified) {
                // Instantly rebuild the dirty chunks in this frame
                terrain.update();
            }
        }
    }
}

// ==========================================
// ANIMATION & PHYSICS LOOP
// ==========================================
function animate() {
    requestAnimationFrame(animate);

    const time = performance.now();
    const delta = Math.min(clock.getDelta(), 0.1); // Clamp delta to avoid massive leaps on frame drops

    // 1. FPS counter update
    fpsFrames++;
    if (time > fpsLastTime + 1000) {
        fpsCounter.textContent = Math.round((fpsFrames * 1000) / (time - fpsLastTime));
        fpsFrames = 0;
        fpsLastTime = time;
    }

    if (controls.isLocked) {
        // 2. Terrain Interaction (Dig/Build holding mouse)
        handleTerrainInteraction();

        // 3. Movement Physics (Gravity & Collisions)
        // Walk controls dampening
        velocity.x -= velocity.x * 10.0 * delta;
        velocity.z -= velocity.z * 10.0 * delta;

        // Apply gravity
        velocity.y -= gravity * delta;

        direction.z = Number(keyStates.KeyW) - Number(keyStates.KeyS);
        direction.x = Number(keyStates.KeyA) - Number(keyStates.KeyD);
        direction.normalize(); // Ensure uniform movement speed

        const currentSpeed = moveSpeed;

        if (keyStates.KeyW || keyStates.KeyS) velocity.z -= direction.z * currentSpeed * delta;
        if (keyStates.KeyA || keyStates.KeyD) velocity.x -= direction.x * currentSpeed * delta;

        // Apply movement vector horizontally
        controls.moveRight(-velocity.x * delta);
        controls.moveForward(-velocity.z * delta);

        // Keep player inside island coordinate boundaries
        const boundX = (terrain.width * terrain.voxelScale) / 2 - 2;
        const boundZ = (terrain.depth * terrain.voxelScale) / 2 - 2;
        camera.position.x = Math.max(-boundX, Math.min(boundX, camera.position.x));
        camera.position.z = Math.max(-boundZ, Math.min(boundZ, camera.position.z));

        // Apply vertical velocity (gravity & jump)
        camera.position.y += velocity.y * delta;

        // Get ground level Y under player position
        // Search downwards starting from slightly above player Y position
        const groundHeight = terrain.getSurfaceHeight(camera.position, camera.position.y + 1.0);

        // Ceiling collision check: if player head goes inside solid terrain
        const headPos = camera.position.clone();
        headPos.y += 0.3; // Check 0.3m above camera eye level
        if (terrain.isPositionSolid(headPos)) {
            // Player hit head: push down slightly and halt upward velocity
            if (velocity.y > 0) {
                velocity.y = 0;
                camera.position.y = terrain.getSurfaceHeight(camera.position, camera.position.y) - 0.3;
            }
        }

        // Floor collision check
        if (camera.position.y - playerHeight <= groundHeight) {
            // Landing on the ground
            camera.position.y = groundHeight + playerHeight;
            velocity.y = 0;
            isGrounded = true;
        } else {
            isGrounded = false;
        }

        // Prevent falling below the water floor level
        if (camera.position.y - playerHeight < 0.5) {
            camera.position.y = 0.5 + playerHeight;
            velocity.y = 0;
            isGrounded = true;
        }

        // 4. Update HUD Coordinates (meters scaled)
        posInfo.textContent = `X: ${Math.round(camera.position.x)} Y: ${Math.round(camera.position.y - 8.0)} Z: ${Math.round(camera.position.z)}`;
    }

    // 5. Water waves animation
    water.material.uniforms['time'].value += delta * 0.5;

    renderer.render(scene, camera);
}
